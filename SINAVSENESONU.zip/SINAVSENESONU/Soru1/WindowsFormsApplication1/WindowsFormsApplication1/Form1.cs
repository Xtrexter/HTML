﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int sayi;
            if (int.TryParse(textBox1.Text, out sayi) && sayi >= 0 && sayi <= 1000)
            {
                label1.Text = SayiyiYaziyaCevir(sayi);
            }
            else
            {
                label1.Text = "Lütfen 0 ile 1000 arasında bir sayı giriniz.";
            }
        }

        private string SayiyiYaziyaCevir(int sayi)
        {
            if (sayi == 0) return "Sıfır";
            if (sayi == 1000) return "Bin";

            string[] birler = { "", "Bir", "İki", "Üç", "Dört", "Beş", "Altı", "Yedi", "Sekiz", "Dokuz" };
            string[] onlar = { "", "On", "Yirmi", "Otuz", "Kırk", "Elli", "Altmış", "Yetmiş", "Seksen", "Doksan" };

            string yazi = "";

            if (sayi >= 100)
            {
                int yuzler = sayi / 100;
                yazi += (yuzler == 1 ? "Yüz" : birler[yuzler] + " Yüz");
                sayi %= 100;
                if (sayi > 0) yazi += " ";
            }

            if (sayi >= 10)
            {
                int on = sayi / 10;
                yazi += onlar[on];
                sayi %= 10;
                if (sayi > 0) yazi += " ";
            }

            if (sayi > 0)
            {
                yazi += birler[sayi];
            }

            return yazi.Trim();
        }
    }
}